package launch;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
@ApplicationPath("/api") // set the path to REST web services
public class ApplicationConfig extends Application {}